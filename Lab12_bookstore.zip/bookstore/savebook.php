<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "bookstore";
$conn = mysqli_connect( $hostname, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");
$BookID=$_POST['BookID'];
$BookName=$_POST['BookName'];
$TypeID=$_POST['TypeID'];
$StatusID=$_POST['StatusID'];
$Publish=$_POST['Publish'];
$UnitPrice=$_POST['UnitPrice'];
$UnitRent=$_POST['UnitRent'];
$DayAmount=$_POST['DayAmount'];
$max_size = $_POST['max_size'];
$ImageFile = $_FILES['ImageFile'];
/*$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$fileimg = $_FILES['fileToUpload'];
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["Submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.<br>";
        echo "<image src='uploads/".$fileimg['name']."' width='320' height='240'>";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

//$conn = mysql_connect( $hostname, $username, $password );
/*if (!$conn) die( "ไม่สามารถติดต่อกับ MySQL ได้" );
mysql_select_db ( $dbname, $conn )or die ( "ไม่สามารถเลือกฐานข้อมูล bookstore ได้" );
mysql_query("SET character_set_results=tis620");
mysql_query("SET character_set_client=tis620");
mysql_query("SET character_set_connection=tis620");*/

$Flag = false;

//ImageFile = htmlspecialchars( trim($ImageFile) );
if ($ImageFile=="") {
    echo "<B><CENTER><li>คุณไม่ได้เลือกรูปภาพ.</CENTER></B><BR>";
}
else {
    //$ImageFile_name; $ImageFile_type; $ImageFile_size;
    $ImageFile_name = $ImageFile['name'];
    $ImageFile_type = $ImageFile['type'];
    $ImageFile_size = $ImageFile['size'];
    $ImageFile_tmp  = $ImageFile['tmp_name'];
    if ($ImageFile_type=="image/gif" or $ImageFile_type=="image/jpeg") {
        if ($ImageFile_size <= $max_size) {
            copy($ImageFile_tmp,"pictures/$ImageFile_name");
            unlink($ImageFile_tmp);
            $image = $ImageFile_name;
            $Flag = true;
        }
        else {
            echo "<CENTER><li>รูปภาพมีขนาดใหญ่กว่า 50 kb.<BR></CENTER>";
            echo "<CENTER><input type=\"button\" value=\"กลับไปแก้ไข\" ";
            echo "onclick=\"history.back();\" style=\"cursor:hand\"></CENTER>";
            $Flag=false;
        }
    }
    else {
        echo "<CENTER><li>รูปภาพไม่ใช่ไฟล์ประเภท GIF หรือ JPG <BR></CENTER>";
        echo "<CENTER><input type=\"button\" value=\"กลับไปแก้ไข\" ";
        echo "onclick=\"history.back();\" style=\"cursor:hand\"></CENTER>";
        $Flag = false;
    }
}
if($Flag)
{
    $BDate = date("Y-m-d");
/*$sql = "INSERT INTO book (BookID ,BookName, TypeID, StatusID, Publish,
UnitPrice,UnitRent, DayAmount ,Picture,BookDate) VALUES
('$BookID','$BookName','$TypeID','$StatusID', '$Publish',
'$UnitPrice','$UnitRent','$DayAmount','$image','$BDate')";*/

    $sqltxt = mysqli_query($conn,"INSERT INTO book (BookID ,BookName, TypeID, StatusID, Publish,
    UnitPrice,UnitRent, DayAmount ,Picture,BookDate) VALUES
    ('$BookID','$BookName','$TypeID','$StatusID', '$Publish',
    '$UnitPrice','$UnitRent','$DayAmount','$image','$BDate')") or die (mysqli_error($conn));

/*mysqli_query($sql,$conn) or die("INSERT ลงตาราง book มีข้อผิดพลาดเกิดขึ้น".
mysql_error());*/
    echo "<br><br><CENTER><H2>บันทึกข้อมูลเรียบร้อย</H2><BR><BR></CENTER>";
    echo "<CENTER><A HREF=\"listofbook.php\">แสดงข้อมูลทั้งหมด</A></CENTER>";
}
mysqli_close($conn);
?>
